document.addEventListener("DOMContentLoaded", () => {
    
    

   

    
    const main = document.createElement("main");
    main.style.padding = "2rem";
    main.style.textAlign = "center";
    main.style.backgroundColor = "rgba(255, 255, 255, 0.9)";
    main.style.borderRadius = "10px";
    main.style.margin = "2rem auto";
    main.style.maxWidth = "800px";
    main.style.boxShadow = "0 4px 10px rgba(0, 0, 0, 0.2)";

    const hero = document.createElement("section");
    hero.className = "hero";
    hero.style.backgroundColor = "rgba(244, 244, 244, 0.8)";
    hero.style.padding = "2rem";
    hero.style.borderRadius = "10px";
    hero.style.boxShadow = "0 2px 5px rgba(0, 0, 0, 0.1)";

    const h1 = document.createElement("h1");
    h1.textContent = "Hoş Geldiniz!";
    const p = document.createElement("p");
    p.textContent = "Kişisel blog sitemde, benim hakkımda merak ettikleriniz var ise, 'Hakkımda' kısmından ulaşabilirsiniz. 'Projelerim' kısmında, üzerinde çalıştığım projeleri ve tamamladıklarımı görebilirsiniz. Benimle iletişime geçmek isterseniz, 'İletişim' kısmından ulaşabilirsiniz.";

    hero.appendChild(h1);
    hero.appendChild(p);
    main.appendChild(hero);
    document.body.appendChild(main);

    const footer = document.createElement("footer");
    footer.style.backgroundColor = "rgba(51, 51, 51, 0.8)";
    footer.style.color = "#fff";
    footer.style.textAlign = "center";
    footer.style.padding = "1rem 0";
    footer.style.position = "fixed";
    footer.style.bottom = "0";
    footer.style.width = "100%";

    const footerText = document.createElement("p");
    footerText.textContent = "© Ömer Hamza Koçak";
    footer.appendChild(footerText);
    document.body.appendChild(footer);
});