document.getElementById('menuButton').onclick = function() {
    var menu = document.getElementById('menu');
    if (menu.style.display === "none" || menu.style.display === "") {
        menu.style.display = "block";  // Menü görünür yap
        this.textContent = "Menüyü Gizle";  // Buton metnini değiştir
    } else {
        menu.style.display = "none";  // Menü gizle
        this.textContent = "Menüyü Göster";  // Buton metnini eski haline getir
    }
}