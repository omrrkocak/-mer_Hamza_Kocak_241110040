document.addEventListener("DOMContentLoaded", () => {

    const footer = document.createElement("footer");
    footer.style.backgroundColor = "rgba(51, 51, 51, 0.8)";
    footer.style.color = "#fff";
    footer.style.textAlign = "center";
    footer.style.padding = "1rem 0";
    footer.style.position = "fixed";
    footer.style.bottom = "0";
    footer.style.width = "100%";

    const footerText = document.createElement("p");
    footerText.textContent = "© Ömer Hamza Koçak";
    footer.appendChild(footerText);
    document.body.appendChild(footer);

});